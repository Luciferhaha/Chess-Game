package UI;


public class Music {
	static boolean flag = true;
}
